package com.example.testalpacaapp_ktor.data

import android.net.http.HttpResponseCache
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.gson.*


class DataSource (val path: String ) {


    private val client = HttpClient () {
        install( ContentNegotiation ) {
            gson()
        }
    }



    suspend fun fetchAlpacaParties() :List <TestAlpacaParty >{

        val alpacaParties: TestAlpacaParties= client.get(path).body()
        return alpacaParties.parties
    }




    suspend fun fetchAlpacaVotes() :List <Stemme >{

        val Stemmer: StemmeListe= client.get(path).body()
        return Stemmer.stemmeListe
    }

    suspend fun StemmeTeller () : Unit {

        val Stemmer: StemmeListe= client.get("https://in2000-proxy.ifi.uio.no/alpacaapi/alpacaparties").body()

        val ant= Stemmer.stemmeListe.size



    }





}