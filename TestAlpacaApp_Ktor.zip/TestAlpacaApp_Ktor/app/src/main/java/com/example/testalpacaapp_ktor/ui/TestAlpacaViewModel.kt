package com.example.testalpacaapp_ktor.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.testalpacaapp_ktor.data.DataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch


class TestAlpacaViewModel: ViewModel() {

    //  DEtte er path for Partier-API:
    private val dataSource= DataSource("https://in2000-proxy.ifi.uio.no/alpacaapi/alpacaparties")
    //  DEtte er path for stemmer-API:
    private val dataSourceVotes =DataSource("https://in2000-proxy.ifi.uio.no/alpacaapi/alpacaparties")




    private val _TestAlpacaUIState= MutableStateFlow (TestAlpacaUiState(parties = listOf()))
    private val _TestAlpacaUIStemme= MutableStateFlow (AlpacaVoteState(stemmeListe = listOf()))


    //Endrer på denne: Nå i dag 18.44
    val testAlpacaUiState: StateFlow<TestAlpacaUiState> = _TestAlpacaUIState.asStateFlow()
    val testAlpacaVote: StateFlow<AlpacaVoteState> = _TestAlpacaUIStemme.asStateFlow()


    init {
        loadUsers()
        loadStemmer()
    }

    private fun loadUsers() {
        viewModelScope.launch (Dispatchers.IO) {
            val alpacapartier = dataSource.fetchAlpacaParties()
            _TestAlpacaUIState.value= TestAlpacaUiState( parties = alpacapartier)
        }
    }


    private fun loadStemmer() {
        viewModelScope.launch (Dispatchers.IO) {
            val stemmer = dataSourceVotes.fetchAlpacaVotes()
            _TestAlpacaUIStemme.value= AlpacaVoteState( stemmeListe = stemmer)
        }
    }


}