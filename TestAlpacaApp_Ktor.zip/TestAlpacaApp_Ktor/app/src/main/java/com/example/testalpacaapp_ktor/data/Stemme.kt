package com.example.testalpacaapp_ktor.data

import com.google.gson.annotations.SerializedName

data class Stemme (

    @SerializedName("id" ) var id : String
// en steme burde også ha en valgt Kandidat String
)